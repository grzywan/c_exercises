int add(int a, int b);
int sub(int a, int b);