#include "libmath.h"

int sub(int a, int b)
{
    return a-b;
}

int add(int a, int b)
{
    int result;

    __asm {
        mov eax, a
        add eax, b
        
        mov result, eax
    };
    return result;
}