#include <stdio.h>
#include "libmath.h"


//Simply calculator with inline assembly language

int select, number1, number2, behavior = 1;

int main()
{
    //standard menu
    while (behavior) {
        printf("\nSelect operation:\n0 - Close program\n1 - Add numbers\n2 - Substract numbers\n");
        scanf_s("%d", &select);
        if (select > 2 || select < 0) {
            printf("\nTry again\n");
            continue;
        }
        else {
            switch (select) {
            case 0:
                printf("\nProgram is end\n");
                behavior = 0;
                getchar();
                break;

            case 1:
                printf("\nSelect numbers to add:\n");
                scanf_s("%d %d", &number1, &number2);
                printf("Result = %d\n", add(number1, number2));
                break;

            case 2:
                printf("\nSelect numbers to substract:\n");
                scanf_s("%d %d", &number1, &number2); 
                printf("Result = %d\n", sub(number1, number2));
                break;
            }
        }

    }

    return 0;
}
